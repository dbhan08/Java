
public class Item {
	String description;
	
	// constructor
	public Item(String newdescription) {
		description = newdescription;
		
	}
	
	public String getDescription() {
		return description;
	}
}
