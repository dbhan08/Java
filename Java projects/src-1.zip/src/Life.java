

public class Life {
	
	

	public static void main(String[] args) {
		new Life();

	}

}
